
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DecimalFormat;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ChoicePanel extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double unitPrice;
	private String flavour;
	private int quantity;
	private JLabel priceLabel = new JLabel("");
	private JLabel quantityLabel = new JLabel("Quantity");
	private Receipt receipt;
	private JLabel priceLbl = new JLabel("Price");
	private JComboBox comboBox = new JComboBox();
	private JSpinner spinner = new JSpinner();
	private JButton clear = new JButton("Clear");
	private double owed;
	private DecimalFormat df = new DecimalFormat("0.00");

	/**
	 * Create the panel.
	 */
	public ChoicePanel() {
		setLayout(new BorderLayout(0, 0));
		setBackground(new Color(255, 255, 255));
		
		{
			JPanel panel = new JPanel();
			panel.setBackground(new Color(255, 255, 255));
			panel.setBorder(null);
			panel.setPreferredSize(new Dimension(550, 10));
			add(panel, BorderLayout.WEST);
			panel.setLayout(null);
			
			JLabel lblSaveurs = new JLabel("Saveurs");
			lblSaveurs.setForeground(new Color(255, 0, 0));
			lblSaveurs.setFont(new Font("Gabriola", Font.PLAIN, 39));
			lblSaveurs.setBounds(17, 18, 106, 30);
			panel.add(lblSaveurs);
			
			quantityLabel.setForeground(Color.RED);
			quantityLabel.setFont(new Font("Gabriola", Font.PLAIN, 39));
			quantityLabel.setBounds(242, 18, 116, 30);
			panel.add(quantityLabel);
			spinner.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
			
			spinner.setEnabled(false);
			spinner.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
			spinner.setFont(new Font("SansSerif", Font.BOLD, 18));
			spinner.setBounds(239, 61, 109, 28);
			panel.add(spinner);
			
			comboBox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent arg0) {
					int index = comboBox.getSelectedIndex();
					switch(index) {
						case 1:
							spinner.setEnabled(true);
							priceLabel.setEnabled(true);
							priceLabel.setText("");
							spinner.setValue(0);
							unitPrice = 2.52;
							flavour = comboBox.getSelectedItem().toString();
							spinner.addChangeListener(new ChangeListener() {
								public void stateChanged(ChangeEvent arg0) {
									quantity = (Integer)spinner.getValue();
									owed = (Integer)quantity * unitPrice;
									priceLabel.setText(df.format(owed) + "$");
								}
							});
						break;
							
						case 2:
							spinner.setEnabled(true);
							priceLabel.setEnabled(true);
							priceLabel.setText("");
							spinner.setValue(0);
							unitPrice = 2;
							flavour = comboBox.getSelectedItem().toString();
							spinner.addChangeListener(new ChangeListener() {
								public void stateChanged(ChangeEvent arg0) {
									quantity = (Integer)spinner.getValue();
									owed = (Integer)quantity * unitPrice;
									priceLabel.setText(df.format(owed) + "$");
								}
							});
						break;
							
						case 3:
							spinner.setEnabled(true);
							priceLabel.setEnabled(true);
							priceLabel.setText("");
							spinner.setValue(0);
							unitPrice = 2.37;
							flavour = comboBox.getSelectedItem().toString();
							spinner.addChangeListener(new ChangeListener() {
								public void stateChanged(ChangeEvent arg0) {
									quantity = (Integer)spinner.getValue();
									owed = (Integer)quantity * unitPrice;
									priceLabel.setText(df.format(owed) + "$");
								}
							});
						break;
							
						default:
							spinner.setEnabled(false);
							priceLabel.setEnabled(false);
							priceLabel.setText("");
							spinner.setValue(0);
					}
				}
			});
			comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"", "Coffee", "Vanilla", "Strawberry"}));
			comboBox.setFont(new Font("Myanmar Text", Font.PLAIN, 16));
			comboBox.setBounds(16, 60, 165, 30);
			panel.add(comboBox);
			
			
			
			priceLbl.setForeground(Color.RED);
			priceLbl.setFont(new Font("Gabriola", Font.PLAIN, 39));
			priceLbl.setBounds(420, 18, 106, 30);
			panel.add(priceLbl);
			
			priceLabel.setEnabled(false);
			priceLabel.setHorizontalAlignment(SwingConstants.CENTER);
			priceLabel.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
			priceLabel.setBounds(420, 61, 106, 30);
			panel.add(priceLabel);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setPreferredSize(new Dimension(70, 70));
			buttonPane.setBackground(new Color(255, 255, 255));
			add(buttonPane, BorderLayout.SOUTH);
			buttonPane.setLayout(null);
			
			
			JButton ok = new JButton("Submit");
			ok.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					receipt = new Receipt(flavour, unitPrice, quantity, owed);
					receipt.show();
				}
			});
			ok.setForeground(Color.WHITE);
			ok.setFont(new Font("Sitka Banner", Font.BOLD, 16));
			ok.setBackground(new Color(34, 139, 34));
			ok.setActionCommand("OK");
			ok.setBounds(278, 6, 119, 39);
			buttonPane.add(ok);
			{
				clear.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						comboBox.setSelectedIndex(0);
						spinner.setEnabled(false);
						priceLabel.setEnabled(false);
					}
				});
				clear.setFont(new Font("Sitka Banner", Font.BOLD, 16));
				clear.setBounds(409, 6, 119, 39);
				clear.setBackground(new Color(255, 69, 0));
				clear.setForeground(new Color(255, 255, 255));
				clear.setActionCommand("OK");
				buttonPane.add(clear);
			}
		}

	}
}
