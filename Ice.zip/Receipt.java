import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class Receipt extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private DecimalFormat df = new DecimalFormat("0.00");

	
	/**
	 * Create the dialog.
	 */
	
	public Receipt(String flavour, double unitPrice, int quantity, double total) {
		setResizable(false);
		setType(Type.UTILITY);
		setTitle("m'icecream bill");
		setBounds(100, 100, 431, 507);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(224, 255, 255));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JLabel lblJavasIcecreamShop = new JLabel("Java's IceCream Shop");
			lblJavasIcecreamShop.setPreferredSize(new Dimension(106, 60));
			lblJavasIcecreamShop.setBorder(new LineBorder(new Color(30, 144, 255), 3, true));
			lblJavasIcecreamShop.setForeground(new Color(30, 144, 255));
			lblJavasIcecreamShop.setHorizontalAlignment(SwingConstants.CENTER);
			lblJavasIcecreamShop.setFont(new Font("Trebuchet MS", Font.BOLD, 27));
			contentPanel.add(lblJavasIcecreamShop, BorderLayout.NORTH);
			{
				JPanel iconPanel = new JPanel();
				iconPanel.setPreferredSize(new Dimension(150, 10));
				contentPanel.add(iconPanel, BorderLayout.WEST);
			}
			{
				JPanel panel = new JPanel();
				panel.setBackground(new Color(224, 255, 255));
				panel.setForeground(new Color(224, 255, 255));
				panel.setPreferredSize(new Dimension(264, 10));
				contentPanel.add(panel, BorderLayout.EAST);
				panel.setLayout(null);
				
				JLabel lblSelectedFlavour = new JLabel("Selected flavour : ");
				lblSelectedFlavour.setHorizontalAlignment(SwingConstants.LEFT);
				lblSelectedFlavour.setFont(new Font("Cambria", Font.PLAIN, 16));
				lblSelectedFlavour.setBounds(6, 45, 128, 16);
				panel.add(lblSelectedFlavour);
				
				JLabel lblUnitPrice = new JLabel("Unit price : ");
				lblUnitPrice.setHorizontalAlignment(SwingConstants.LEFT);
				lblUnitPrice.setFont(new Font("Cambria", Font.PLAIN, 16));
				lblUnitPrice.setBounds(6, 138, 128, 16);
				panel.add(lblUnitPrice);
				
				JLabel lblOderedQuantity = new JLabel("Ordered quantity : ");
				lblOderedQuantity.setHorizontalAlignment(SwingConstants.LEFT);
				lblOderedQuantity.setFont(new Font("Cambria", Font.PLAIN, 16));
				lblOderedQuantity.setBounds(6, 231, 164, 16);
				panel.add(lblOderedQuantity);
				
				JLabel lblTotal = new JLabel("Total : ");
				lblTotal.setFont(new Font("hooge 05_54", Font.PLAIN, 16));
				lblTotal.setBounds(49, 301, 86, 23);
				panel.add(lblTotal);
				
				JLabel flavourTextField = new JLabel(flavour);
				flavourTextField.setFont(new Font("SansSerif", Font.BOLD, 12));
				flavourTextField.setHorizontalAlignment(SwingConstants.CENTER);
				flavourTextField.setBorder(new LineBorder(new Color(30, 144, 255), 1, true));
				flavourTextField.setBounds(178, 40, 86, 28);
				panel.add(flavourTextField);
				
				JLabel unitPriceTextField = new JLabel(unitPrice+"$");
				unitPriceTextField.setFont(new Font("SansSerif", Font.BOLD, 12));
				unitPriceTextField.setHorizontalAlignment(SwingConstants.CENTER);
				unitPriceTextField.setBorder(new LineBorder(new Color(30, 144, 255), 1, true));
				unitPriceTextField.setBounds(178, 126, 86, 28);
				panel.add(unitPriceTextField);
				
				JLabel orderedQuantityTextField = new JLabel(quantity+"");
				orderedQuantityTextField.setFont(new Font("SansSerif", Font.BOLD, 12));
				orderedQuantityTextField.setHorizontalAlignment(SwingConstants.CENTER);
				orderedQuantityTextField.setBorder(new LineBorder(new Color(30, 144, 255), 1, true));
				orderedQuantityTextField.setBounds(178, 219, 86, 28);
				panel.add(orderedQuantityTextField);
				
				JLabel totalTextField = new JLabel(df.format(total)+"$");
				totalTextField.setFont(new Font("SansSerif", Font.BOLD, 12));
				totalTextField.setHorizontalAlignment(SwingConstants.CENTER);
				totalTextField.setBorder(new LineBorder(new Color(30, 144, 255), 1, true));
				totalTextField.setBounds(147, 296, 86, 28);
				panel.add(totalTextField);
			}
			
			JPanel buttonPane = new JPanel();
			buttonPane.setPreferredSize(new Dimension(10, 50));
			buttonPane.setBackground(new Color(224, 255, 255));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			buttonPane.setLayout(null);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						dispose();
					}
				});
				okButton.setBackground(new Color(34, 139, 34));
				okButton.setBounds(170, 0, 85, 39);
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
	}
}