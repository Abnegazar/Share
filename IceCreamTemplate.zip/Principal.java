 

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;

import java.awt.Color;
import javax.swing.border.EtchedBorder;
import java.awt.Dimension;
import javax.swing.border.LineBorder;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JButton;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Dialog.ModalExclusionType;

public class Principal extends JFrame {
	
	private ChoicePanel cp;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public Principal() {
		setModalExclusionType(ModalExclusionType.TOOLKIT_EXCLUDE);
		setPreferredSize(new Dimension(567, 368));
		setResizable(false);
		setMinimumSize(new Dimension(567, 368));
		setMaximumSize(new Dimension(567, 368));
		try {
		    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
		        if ("Nimbus".equals(info.getName())) {
		            UIManager.setLookAndFeel(info.getClassName());
		            break;
		        }
		    }
		} catch (Exception e) {
		    // If Nimbus is not available, you can set the GUI to another look and feel.
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(224, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JLabel lblJavasIcecreamShop = new JLabel("Java's IceCream Shop");
		lblJavasIcecreamShop.setPreferredSize(new Dimension(106, 60));
		lblJavasIcecreamShop.setBorder(new LineBorder(new Color(30, 144, 255), 3, true));
		lblJavasIcecreamShop.setForeground(new Color(30, 144, 255));
		lblJavasIcecreamShop.setHorizontalAlignment(SwingConstants.CENTER);
		lblJavasIcecreamShop.setFont(new Font("Trebuchet MS", Font.BOLD, 27));
		contentPane.add(lblJavasIcecreamShop, BorderLayout.NORTH);
		
		cp = new ChoicePanel();
		cp.setBackground(new Color(224, 255, 255));
		contentPane.add(cp, BorderLayout.CENTER);		
		
	}

}
