 

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DecimalFormat;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ChoicePanel extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double prixUnit;
	private String saveur;
	private int quant;
	private JLabel labelPrix = new JLabel("");
	private JLabel lblQuantit = new JLabel("Quantit\u00E9");
	private Facture facture;
	private JLabel lblPrix = new JLabel("Prix");
	private JComboBox comboBox = new JComboBox();
	private JSpinner spinner = new JSpinner();
	private JButton cancel = new JButton("Clear");
	private double aPayer;
	private DecimalFormat df = new DecimalFormat("0.00");

	/**
	 * Create the panel.
	 */
	public ChoicePanel() {
		setLayout(new BorderLayout(0, 0));
		setBackground(new Color(255, 255, 255));
		
		{
			JPanel panel = new JPanel();
			panel.setBackground(new Color(255, 255, 255));
			panel.setBorder(null);
			panel.setPreferredSize(new Dimension(550, 10));
			add(panel, BorderLayout.WEST);
			panel.setLayout(null);
			
			JLabel lblSaveurs = new JLabel("Saveurs");
			lblSaveurs.setForeground(new Color(255, 0, 0));
			lblSaveurs.setFont(new Font("Gabriola", Font.PLAIN, 39));
			lblSaveurs.setBounds(17, 18, 106, 30);
			panel.add(lblSaveurs);
			
			lblQuantit.setForeground(Color.RED);
			lblQuantit.setFont(new Font("Gabriola", Font.PLAIN, 39));
			lblQuantit.setBounds(242, 18, 106, 30);
			panel.add(lblQuantit);
			spinner.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
			
			spinner.setEnabled(false);
			spinner.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
			spinner.setFont(new Font("SansSerif", Font.BOLD, 18));
			spinner.setBounds(239, 61, 109, 28);
			panel.add(spinner);
			
			comboBox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent arg0) {
					int index = comboBox.getSelectedIndex();
					switch(index) {
						case 1:
							spinner.setEnabled(true);
							labelPrix.setEnabled(true);
							labelPrix.setText("");
							spinner.setValue(0);
							prixUnit = 2.52;
							saveur = comboBox.getSelectedItem().toString();
							spinner.addChangeListener(new ChangeListener() {
								public void stateChanged(ChangeEvent arg0) {
									quant = (Integer)spinner.getValue();
									aPayer = (Integer)quant * prixUnit;
									labelPrix.setText(df.format(aPayer) + "$");
								}
							});
						break;
							
						case 2:
							spinner.setEnabled(true);
							labelPrix.setEnabled(true);
							labelPrix.setText("");
							spinner.setValue(0);
							prixUnit = 2;
							saveur = comboBox.getSelectedItem().toString();
							spinner.addChangeListener(new ChangeListener() {
								public void stateChanged(ChangeEvent arg0) {
									quant = (Integer)spinner.getValue();
									aPayer = (Integer)quant * prixUnit;
									labelPrix.setText(df.format(aPayer) + "$");
								}
							});
						break;
							
						case 3:
							spinner.setEnabled(true);
							labelPrix.setEnabled(true);
							labelPrix.setText("");
							spinner.setValue(0);
							prixUnit = 2.37;
							saveur = comboBox.getSelectedItem().toString();
							spinner.addChangeListener(new ChangeListener() {
								public void stateChanged(ChangeEvent arg0) {
									quant = (Integer)spinner.getValue();
									aPayer = (Integer)quant * prixUnit;
									labelPrix.setText(df.format(aPayer) + "$");
								}
							});
						break;
							
						default:
							spinner.setEnabled(false);
							labelPrix.setEnabled(false);
							labelPrix.setText("");
							spinner.setValue(0);
					}
				}
			});
			comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"", "Caf\u00E9", "Vanille", "Fraise"}));
			comboBox.setFont(new Font("Myanmar Text", Font.PLAIN, 16));
			comboBox.setBounds(16, 60, 165, 30);
			panel.add(comboBox);
			
			
			
			lblPrix.setForeground(Color.RED);
			lblPrix.setFont(new Font("Gabriola", Font.PLAIN, 39));
			lblPrix.setBounds(420, 18, 106, 30);
			panel.add(lblPrix);
			
			labelPrix.setEnabled(false);
			labelPrix.setHorizontalAlignment(SwingConstants.CENTER);
			labelPrix.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
			labelPrix.setBounds(420, 61, 106, 30);
			panel.add(labelPrix);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setPreferredSize(new Dimension(70, 70));
			buttonPane.setBackground(new Color(255, 255, 255));
			add(buttonPane, BorderLayout.SOUTH);
			buttonPane.setLayout(null);
			
			
			JButton ok = new JButton("Submit");
			ok.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					facture = new Facture(saveur, prixUnit, quant, aPayer);
					facture.show();
				}
			});
			ok.setForeground(Color.WHITE);
			ok.setFont(new Font("Sitka Banner", Font.BOLD, 16));
			ok.setBackground(new Color(34, 139, 34));
			ok.setActionCommand("OK");
			ok.setBounds(278, 6, 119, 39);
			buttonPane.add(ok);
			{
				cancel.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						comboBox.setSelectedIndex(0);
						spinner.setEnabled(false);
						labelPrix.setEnabled(false);
					}
				});
				cancel.setFont(new Font("Sitka Banner", Font.BOLD, 16));
				cancel.setBounds(409, 6, 119, 39);
				cancel.setBackground(new Color(255, 69, 0));
				cancel.setForeground(new Color(255, 255, 255));
				cancel.setActionCommand("OK");
				buttonPane.add(cancel);
			}
		}

	}
}
