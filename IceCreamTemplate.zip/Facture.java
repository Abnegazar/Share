 

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class Facture extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private DecimalFormat df = new DecimalFormat("0.00");

	
	/**
	 * Create the dialog.
	 */
	
	public Facture(String saveur, double prixUnit, int quant, double total) {
		setResizable(false);
		setType(Type.UTILITY);
		setTitle("m'icecream bill");
		setBounds(100, 100, 431, 507);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(224, 255, 255));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JLabel lblJavasIcecreamShop = new JLabel("Java's IceCream Shop");
			lblJavasIcecreamShop.setPreferredSize(new Dimension(106, 60));
			lblJavasIcecreamShop.setBorder(new LineBorder(new Color(30, 144, 255), 3, true));
			lblJavasIcecreamShop.setForeground(new Color(30, 144, 255));
			lblJavasIcecreamShop.setHorizontalAlignment(SwingConstants.CENTER);
			lblJavasIcecreamShop.setFont(new Font("Trebuchet MS", Font.BOLD, 27));
			contentPanel.add(lblJavasIcecreamShop, BorderLayout.NORTH);
			{
				JPanel iconPanel = new JPanel();
				iconPanel.setPreferredSize(new Dimension(150, 10));
				contentPanel.add(iconPanel, BorderLayout.WEST);
			}
			{
				JPanel panel = new JPanel();
				panel.setBackground(new Color(224, 255, 255));
				panel.setForeground(new Color(224, 255, 255));
				panel.setPreferredSize(new Dimension(264, 10));
				contentPanel.add(panel, BorderLayout.EAST);
				panel.setLayout(null);
				
				JLabel lblSaveurChoisie = new JLabel("Saveur choisie : ");
				lblSaveurChoisie.setHorizontalAlignment(SwingConstants.LEFT);
				lblSaveurChoisie.setFont(new Font("Cambria", Font.PLAIN, 16));
				lblSaveurChoisie.setBounds(6, 45, 128, 16);
				panel.add(lblSaveurChoisie);
				
				JLabel lblPrixUnitaire = new JLabel("Prix unitaire : ");
				lblPrixUnitaire.setHorizontalAlignment(SwingConstants.LEFT);
				lblPrixUnitaire.setFont(new Font("Cambria", Font.PLAIN, 16));
				lblPrixUnitaire.setBounds(6, 138, 128, 16);
				panel.add(lblPrixUnitaire);
				
				JLabel lblQuantitCommande = new JLabel("Quantit\u00E9 command\u00E9e : ");
				lblQuantitCommande.setHorizontalAlignment(SwingConstants.LEFT);
				lblQuantitCommande.setFont(new Font("Cambria", Font.PLAIN, 16));
				lblQuantitCommande.setBounds(6, 231, 164, 16);
				panel.add(lblQuantitCommande);
				
				JLabel lblTotal = new JLabel("Total : ");
				lblTotal.setFont(new Font("hooge 05_54", Font.PLAIN, 16));
				lblTotal.setBounds(49, 301, 86, 23);
				panel.add(lblTotal);
				
				JLabel saveurTF = new JLabel(saveur);
				saveurTF.setFont(new Font("SansSerif", Font.BOLD, 12));
				saveurTF.setHorizontalAlignment(SwingConstants.CENTER);
				saveurTF.setBorder(new LineBorder(new Color(30, 144, 255), 1, true));
				saveurTF.setBounds(178, 40, 86, 28);
				panel.add(saveurTF);
				
				JLabel prixUnitTF = new JLabel(prixUnit+"$");
				prixUnitTF.setFont(new Font("SansSerif", Font.BOLD, 12));
				prixUnitTF.setHorizontalAlignment(SwingConstants.CENTER);
				prixUnitTF.setBorder(new LineBorder(new Color(30, 144, 255), 1, true));
				prixUnitTF.setBounds(178, 126, 86, 28);
				panel.add(prixUnitTF);
				
				JLabel quComTF = new JLabel(quant+"");
				quComTF.setFont(new Font("SansSerif", Font.BOLD, 12));
				quComTF.setHorizontalAlignment(SwingConstants.CENTER);
				quComTF.setBorder(new LineBorder(new Color(30, 144, 255), 1, true));
				quComTF.setBounds(178, 219, 86, 28);
				panel.add(quComTF);
				
				JLabel totalTF = new JLabel(df.format(total)+"$");
				totalTF.setFont(new Font("SansSerif", Font.BOLD, 12));
				totalTF.setHorizontalAlignment(SwingConstants.CENTER);
				totalTF.setBorder(new LineBorder(new Color(30, 144, 255), 1, true));
				totalTF.setBounds(147, 296, 86, 28);
				panel.add(totalTF);
			}
			
			JPanel buttonPane = new JPanel();
			buttonPane.setPreferredSize(new Dimension(10, 50));
			buttonPane.setBackground(new Color(224, 255, 255));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			buttonPane.setLayout(null);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						dispose();
					}
				});
				okButton.setBackground(new Color(34, 139, 34));
				okButton.setBounds(170, 0, 85, 39);
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
	}
}
